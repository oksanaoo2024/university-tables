// 1. Дані сутності «Студенти»
const students = [
  { id: 1, fullName: "Іваненко Марія", group: "КН-21", specialty: "Комп'ютерні науки", year: 2, averageGrade: 91, email: "m.ivanenko@example.com" },
  { id: 2, fullName: "Петренко Максим", group: "КБ-31", specialty: "Кібербезпека", year: 3, averageGrade: 87, email: "m.petrenko@example.com" },
  { id: 3, fullName: "Коваль Софія", group: "ІПЗ-11", specialty: "Інженерія програмного забезпечення", year: 1, averageGrade: 95, email: "s.koval@example.com" },
  { id: 4, fullName: "Мельник Андрій", group: "КН-21", specialty: "Комп'ютерні науки", year: 2, averageGrade: 78, email: "a.melnyk@example.com" },
  { id: 5, fullName: "Шевченко Дарина", group: "КБ-31", specialty: "Кібербезпека", year: 3, averageGrade: 89, email: "d.shevchenko@example.com" }
];

// 2. Дані сутності «Викладачі»
const teachers = [
  { id: 1, fullName: "Олена Бондар", department: "Комп'ютерних наук", position: "Доцент", degree: "Кандидат технічних наук", subject: "Вебпрограмування", email: "o.bondar@example.com" },
  { id: 2, fullName: "Сергій Ткачук", department: "Кібербезпеки", position: "Професор", degree: "Доктор технічних наук", subject: "Захист інформації", email: "s.tkachuk@example.com" },
  { id: 3, fullName: "Ірина Савчук", department: "Математики", position: "Старший викладач", degree: "Кандидат фізико-математичних наук", subject: "Дискретна математика", email: "i.savchuk@example.com" },
  { id: 4, fullName: "Андрій Романюк", department: "Комп'ютерних наук", position: "Доцент", degree: "Кандидат технічних наук", subject: "Бази даних", email: "a.romaniuk@example.com" },
  { id: 5, fullName: "Наталія Лисенко", department: "Кібербезпеки", position: "Асистент", degree: "Без наукового ступеня", subject: "Комп'ютерні мережі", email: "n.lysenko@example.com" }
];

// 3. Дані сутності «Дисципліни»
const courses = [
  { id: 1, name: "Вебпрограмування", credits: 5, semester: 3, assessment: "Екзамен", teacher: "Олена Бондар", hours: 150 },
  { id: 2, name: "Захист інформації", credits: 4, semester: 5, assessment: "Екзамен", teacher: "Сергій Ткачук", hours: 120 },
  { id: 3, name: "Дискретна математика", credits: 4, semester: 1, assessment: "Залік", teacher: "Ірина Савчук", hours: 120 },
  { id: 4, name: "Бази даних", credits: 5, semester: 4, assessment: "Екзамен", teacher: "Андрій Романюк", hours: 150 },
  { id: 5, name: "Комп'ютерні мережі", credits: 4, semester: 5, assessment: "Залік", teacher: "Наталія Лисенко", hours: 120 }
];

// Функція створює заголовок і рядки таблиці на основі даних масиву.
function renderTable(entityName, data, columns) {
  const head = document.getElementById(`${entityName}-head`);
  const body = document.getElementById(`${entityName}-body`);
  const count = document.getElementById(`${entityName}-count`);

  // Формування заголовків стовпців.
  head.innerHTML = `<tr>${columns.map(column => `<th>${column.label}</th>`).join("")}</tr>`;

  // Формування рядків таблиці.
  body.innerHTML = data.map(item => {
    const cells = columns.map(column => `<td>${item[column.key]}</td>`).join("");
    return `<tr>${cells}</tr>`;
  }).join("");

  count.textContent = `${data.length} записів`;
}

// Опис стовпців для кожної сутності.
renderTable("students", students, [
  { key: "id", label: "ID" },
  { key: "fullName", label: "ПІБ" },
  { key: "group", label: "Група" },
  { key: "specialty", label: "Спеціальність" },
  { key: "year", label: "Курс" },
  { key: "averageGrade", label: "Середній бал" },
  { key: "email", label: "Електронна пошта" }
]);

renderTable("teachers", teachers, [
  { key: "id", label: "ID" },
  { key: "fullName", label: "ПІБ" },
  { key: "department", label: "Кафедра" },
  { key: "position", label: "Посада" },
  { key: "degree", label: "Науковий ступінь" },
  { key: "subject", label: "Дисципліна" },
  { key: "email", label: "Електронна пошта" }
]);

renderTable("courses", courses, [
  { key: "id", label: "ID" },
  { key: "name", label: "Назва дисципліни" },
  { key: "credits", label: "Кредити ЄКТС" },
  { key: "semester", label: "Семестр" },
  { key: "assessment", label: "Форма контролю" },
  { key: "teacher", label: "Викладач" },
  { key: "hours", label: "Кількість годин" }
]);

// Перемикання табів без перезавантаження сторінки.
const tabs = document.querySelectorAll(".tab");
const panels = document.querySelectorAll(".table-panel");

tabs.forEach(tab => {
  tab.addEventListener("click", () => {
    const targetId = tab.dataset.target;

    tabs.forEach(item => {
      const isActive = item === tab;
      item.classList.toggle("active", isActive);
      item.setAttribute("aria-selected", String(isActive));
    });

    panels.forEach(panel => {
      panel.classList.toggle("active", panel.id === targetId);
    });
  });
});
